<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>

<div id="wrapper">
	<div class="content">
		<div class="row">
			<div class="col-lg-12">
					<div class="alert alert-warning">
						Eraxon Assets Module
					</div>
				</div>
			</div>
		</div>
	</div>

<?php init_tail();?> 
<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}
class Eraxon_assets_request_inventory extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('staff_model');
        $this->load->model('roles_model');
        $this->load->model('Eraxon_assets_allocation_model');
        $this->load->model('Eraxon_assets_loss_model');

    }

    public function index()
    {
        if (!has_permission('asset-inventory', '', 'view')) {
            access_denied('Assets Inventory');
        }
        $this->load->view('eraxon_assets/request_inventory');
    }

    



}

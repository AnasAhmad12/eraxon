<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
    <div class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="tw-mb-2 sm:tw-mb-4">
                    <?php if (has_permission('asset-loss', '', 'create') || is_admin()) { ?>
                        <a href="#" onclick="new_advance_salary(); return false;" class="btn btn-primary">
                            <i class="fa-regular fa-plus tw-mr-1"></i>
                            <?php echo "Report Loss"; ?>
                        </a>
                    <?php } ?>
                </div>
                <div class="panel_s">
                    <div class="panel-body panel-table-full">
                        <table class="table dt-table" data-order-col="1" data-order-type="asc">

                            <thead>

                                    <th>Staff Name</th>
                                <th>Item Name</th>
                                <th> Serial Number </th>
                                <th>Reason</th>
                                <th>Request Status</th>
                                <th>Item Status</th>
                                <?php if (has_permission('asset-loss','','edit')) { ?>
                                <th>
                                    <?php echo _l('options'); ?>
                                </th>
                                <?php } ?>

                            </thead>
                            <tbody>
                                <?php foreach ($loss as $l) { ?>

                                    <tr data-item="<?php echo $l->item_status ?>" data-id="<?php echo $l->id ?> " data-request="<?php echo $l->request_status ?>">

                                        <td>
                                            <?php echo get_staff_full_name($l->staff_id) ?>
                                        </td>
                                        <td>
                                            <?php echo $l->item_name ?>
                                        </td>
                                        <td>
                                            <?php echo $l->serial_number ?>
                                        </td>
                                        <td>
                                            <?php echo $l->reason ?>
                                        </td>
                                        <td>
                                            <?php if ($l->request_status == 0) {
                                                echo "Pending";
                                            } elseif ($l->request_status == 1) {
                                                echo "Approved";
                                            } else {
                                                echo 'Rejected';
                                            }

                                            ?>
                                        </td>
                                        <td>
                                        <?php if ($l->request_status == 0) {
                                                echo "Pending";
                                            } elseif ($l->request_status == 1) {
                                                echo "Rapaired";
                                            } else {
                                                echo 'Non-Repairable/Dump';
                                            }
                                            ?>
                                        </td>

                                        <td>
                                            <div class="tw-flex tw-items-center tw-space-x-3">
                                            <?php if (true) { ?>
                                                    <a href="#"
                                                        class="edit_request tw-text-neutral-500 hover:tw-text-neutral-700 focus:tw-text-neutral-700"
                                                        data-hide-from-client="0">

                                                        <i class="fa-regular fa-pen-to-square fa-lg"></i>
                                                    </a>
                                                <?php }
                                                if (has_permission('asset-loss', '', 'delete') || is_admin()) { ?>
                                                    <a href="<?php echo admin_url('eraxon_/delete_or/' . $l->id); ?>"
                                                        class="tw-mt-px tw-text-neutral-500 hover:tw-text-neutral-700 focus:tw-text-neutral-700 _delete">
                                                        <i class="fa-regular fa-trash-can fa-lg"></i>
                                                    </a>
                                                <?php } ?>
                                            </div>
                                        </td>




                                    </tr>

                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="other_requests" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <?php echo form_open(admin_url('eraxon_assets/eraxon_assets_loss_management/add_loss')); ?>
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">
                    <span class="add-title">Add Loss Item</span>
                </h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div id="additional"></div>
                        <div class="form-group">
                            <label for="amount">Select Item</label>
                            <select class="form-control" name="item">
                                <?php foreach ($staff_items as $si) { ?>
                                    <option value="<?php echo $si->item_id . "-" . $si->serial_number ?>">
                                        <?php echo $si->item_name . " " . $si->serial_number ?>
                                    </option>
                                <?php } ?>
                            </select>

                        </div>
                        <?php
                        $contents = '';
                        echo render_textarea('loss_reason', 'Reason');

                        ?>
                        <input type="hidden" name="staff_id" value="<?php echo $current_user->staffid; ?>">
                    </div>


                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">
                    <?php echo _l('close'); ?>
                </button>
                <button type="submit" class="btn btn-primary">
                    <?php echo _l('submit'); ?>
                </button>
            </div>
        </div>
        <!-- /.modal-content -->
        <?php echo form_close(); ?>
    </div>
    <!-- /.modal-dialog -->
</div>


<div class="modal fade" id="status_edit" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <?php echo form_open(admin_url('eraxon_assets/eraxon_assets_loss_management/edit_loss')); ?>
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">
                    <span class="add-title">Add Loss Item</span>
                </h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div id="additional_loss"></div>
                        <input type="hidden" name="staff_id" value="<?php echo $current_user->staffid; ?>">
                    </div>

                    <div class="col-md-12" id="status">
                        <label for="status" class="control-label">Request Status</label>
                        <select name="request_status" class="selectpicker" id="status" data-width="100%"
                            data-none-selected-text="<?php echo _l('none_type'); ?>">
                            <option value="0">Pending</option>
                            <option value="1">Accepted</option>
                            <option value="2">Rejected</option>
                        </select>
                    </div>

                    <div class="col-md-12" id="status">
                        <label for="status" class="control-label">Item Status</label>
                        <select name="item_status" class="selectpicker" id="status" data-width="100%"
                            data-none-selected-text="<?php echo _l('none_type'); ?>">
                            <option value="0">Repairing</option>
                            <option value="1">Non-Repairable/Dump</option>
                            <option value="2">Repaired/Working</option>
                        </select>
                    </div>


                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">
                    <?php echo _l('close'); ?>
                </button>
                <button type="submit" class="btn btn-primary">
                    <?php echo _l('submit'); ?>
                </button>
            </div>
        </div>
        <!-- /.modal-content -->
        <?php echo form_close(); ?>
    </div>
    <!-- /.modal-dialog -->
</div>
<?php init_tail(); ?>
<script>
    $(function () {
        appValidateForm($('form'), {
            item: 'required',
            loss_reason: 'required',
        }, manage_advance_salary);
        $('#other_requests').on('hidden.bs.modal', function (event) {
            $('#additional').html('');
            $('.add-title').removeClass('hide');
            $('.edit-title').removeClass('hide');
        });
    });

    function manage_advance_salary(form) {
        var data = $(form).serialize();


        var url = form.action;
        $.post(url, data).done(function (response) {

            window.location.reload();

        });
        return false;
    }

    function new_advance_salary() {
        $('#other_requests select[name="request_type"]').val('');
        $('#other_requests').modal('show');
        $('.edit-title').addClass('hide');
    }


    $(document).on('click', '.edit_request', function (e) {
        e.preventDefault();

        var request_status = $(this).parents("tr").attr("data-request");
        var item_status = $(this).parents("tr").attr("data-item");

        console.log("Item s",item_status)

        var id = $(this).parents("tr").attr("data-id");

        setDefaultOptionByStatus(request_status,item_status);



        $('#additional_loss').append(hidden_input('id_loss', id));
        $('#status_edit').modal('show');
        $('.add-title').addClass('hide');

    });


    function edit_as_request(invoker, id) {

        console.log("ID", id);

    }

    function setDefaultOptionByStatus(status,item_status) {
        var selectElement = $('select[name="request_status"]');
        selectElement.find('option').each(function () {
            if ($(this).val() === status) {
                $(this).prop('selected', true);
            } else {
                $(this).prop('selected', false);
            }
        });
        selectElement.selectpicker('refresh');

        var item = $('select[name="item_status"]');
        item.find('option').each(function () {
            if ($(this).val() === item_status) {
                $(this).prop('selected', true);
            } else {
                $(this).prop('selected', false);
            }
        });
        item.selectpicker('refresh');
    }



</script>